export { NavBar as default } from "./NavBar";
