export const ModalBody = ({ children }) => (
    <div className="mt-6 flex flex-col justify-center">
        {children}
    </div>
)