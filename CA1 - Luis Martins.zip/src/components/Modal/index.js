export { Modal } from "./Modal";
export { useModal } from "./hooks/useModal";
export { ModalContext } from "./context/ModalContext";