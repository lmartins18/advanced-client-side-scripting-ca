export const FormatedTextSpan = ({ children }) => (
    <span className="text-emerald-700 font-uncial underline underline-offset-4">{children}</span>
)