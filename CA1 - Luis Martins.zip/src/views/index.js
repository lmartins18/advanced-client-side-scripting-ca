export { Home } from "./Home"
export { Accommodation } from "./Accommodation";
export { Attractions } from "./Attractions/Attractions"
export { Contact } from "./Contact"
